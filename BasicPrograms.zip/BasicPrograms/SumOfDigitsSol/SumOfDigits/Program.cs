﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0; ;
            Console.WriteLine("Enter the number");
            int n = Convert.ToInt32(Console.ReadLine());
            int s = n;

            while(s>0)
            {
                
                sum=sum+ s % 10;
                s = s / 10;

            }
            Console.WriteLine("Totsl sum of the digits is {0}", sum);

            Console.ReadKey();
        }
    }
}
