﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DecimalToBinary
{
    class Program
    {
        static void Main(string[] args)
        {
            int s = 0;
            // int[] bnry = new int[10];

            var arylist = new ArrayList();
            Console.WriteLine("Enter the decimal");
            int i = Convert.ToInt32(Console.ReadLine());
            int n = i;
            for (int j = 0; n > 0; j++)
            {
                s = n % 2;
                arylist.Add(s);
                n = n / 2;
            }
            Console.WriteLine("Binary value is ");
            for (int j = arylist.Count-1; j >=0 ; j--)
            {

                Console.Write(arylist[j]);
            }

            Console.ReadKey();
        }
    }
}
