﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseTheNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int j=0;
            Console.WriteLine("Enter the number");
            int i = Convert.ToInt32(Console.ReadLine());
            int n = i;

            while(n>0)
            {
                //n = n % 10;
                j = (j * 10) + n%10;
                n = n / 10;
            }

            Console.WriteLine("Reverse of {0} is {1}", i, j);

            Console.ReadKey();
        }
    }
}
