﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToChar
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the number");
            int i = Convert.ToInt32(Console.ReadLine());
            int n = i;

            var arlist = new ArrayList();
            while (n > 0)
            {
                arlist.Add(n%10);
                n = n / 10;
            }

            for(int j=arlist.Count-1;j>=0;j--)
            {
                int ch = Convert.ToInt32(arlist[j]);

                switch (ch)
                {
                    case 1:
                        Console.Write("One\t");
                        break;
                    case 2:
                        Console.WriteLine("Two");
                        break;
                    case 3:
                        Console.WriteLine("Three");
                        break;
                    case 4:
                        Console.WriteLine("Four");
                        break;
                    case 5:
                        Console.WriteLine("Five");
                        break;
                    case 6:
                        Console.WriteLine("Six");
                        break;
                    case 7:
                        Console.WriteLine("Seven");
                        break;
                    case 8:
                        Console.WriteLine("Eight");
                        break;
                    case 9:
                        Console.WriteLine("Nine");
                        break;
                    case 0:
                        Console.WriteLine("Zero");
                        break;
                    default:
                        Console.WriteLine("Not Valid");
                        break;

                        Console.Write("\t");

                }
                    
            }

            Console.ReadKey();
        }
    }
}
