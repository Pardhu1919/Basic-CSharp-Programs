﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwapNumber
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the first number\n");

            int a= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second number\n");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Before swap a={0}, b={1}", a, b);

            a = a + b;
            b = a - b;
            a = a - b;

            Console.WriteLine("After swap a={0}, b={1}", a, b);

            Console.ReadKey();
        }
    }
}
