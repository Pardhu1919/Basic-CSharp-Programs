﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonacciSeries
{
    class Program
    {
        static void Main(string[] args)
        {
            int i1 = 0, i2 = 1, i3;
            Console.WriteLine("Enter fibonacci series elements");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("{0}\n{1}", i1, i2);

            for (int i = 2; i <n; i++)
            {
                i3 = i1 + i2;
                Console.WriteLine(i3);
                i1 = i2;
                i2 = i3;
            }

            Console.ReadKey();
        }
    }
}
