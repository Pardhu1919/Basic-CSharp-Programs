﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArmStrong
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            double d = 0;
            Console.WriteLine("Enter the number to check for Armstrong");
            int s = Convert.ToInt32(Console.ReadLine());
            int n = s;

            while (n > 0){
                i = n % 10;

                d = d+ Math.Pow(i, 3);
                n = n / 10;
                
            }

            if (s == d)
                Console.WriteLine("Entered number {0} is Armstrong",s);
            else
                Console.WriteLine("Entered number {0} is not Armstrong", s);

            Console.ReadKey();
        }
    }
}
