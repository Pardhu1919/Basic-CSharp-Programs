﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, r = 0, sum = 0;

            Console.WriteLine("Enter number to check");
            int i = Convert.ToInt32(Console.ReadLine());
            n = i;

            while (n > 0)
            {

                r = n % 10;
                sum = (sum * 10) + r;
                n = n / 10;

            }
            if (sum == i)
                Console.WriteLine("Entered number {0} is a palindrome", i);
            else
                Console.WriteLine("Entered number {0} is not a palindrome", i);

            Console.ReadKey();
        }
    }
}
