﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumber
{
    class Program
    {
        static void Main(string[] args)
        {

            bool isPrime = true;
            int cnt = 0;
            Console.WriteLine("Enter prime number elements count");
            int n = Convert.ToInt32(Console.ReadLine());

            for (int i = 2; i < n; i++)
            {
                for (int j = 2; j <= i; j++)
                {
                    if (i != j && i % j == 0)
                    {
                        isPrime = false;
                        break;
                    }
                    isPrime = true;
                }

                if (isPrime)
                {
                    Console.WriteLine(i);
                    cnt++;
                }
            }

            Console.WriteLine("Total Count is {0}", cnt);

            // To find number is prime or not
            //int cnt = 0;
            //Console.WriteLine("Enter number to check");
            //int n = Convert.ToInt32(Console.ReadLine());
            //for(int i=2;i<=n;i++)
            //{
            //    if (n % i == 0)
            //        cnt++;
            //}    
            //if(cnt==1)
            //    Console.WriteLine("{0} entered Number is prime",n);
            //else
            //    Console.WriteLine("{0} entered Number is not a prime", n);

            Console.ReadKey();
        }
    }
}
